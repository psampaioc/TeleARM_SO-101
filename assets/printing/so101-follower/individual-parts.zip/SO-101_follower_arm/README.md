# SO-101 follower arm — files for 3D printing

Source: [TheRobotStudio/SO-ARM100 official GitHub repository](https://github.com/TheRobotStudio/SO-ARM100#sourcing-parts).

This folder contains the **11 individual STL parts** listed by the official
SO-101 README for one follower arm, plus `Gauge_0.STL` for the servo-fit
check. The STL files were verified against the official repository on
2026-09-15 (upstream `main` commit `eecbe3e0a9ebb23e25ad7b2759b03884c6660903`).

## Print setup and accuracy check

> **Adapted from the official TheRobotStudio SO-ARM100 README** (minor
> formatting edits for this print package):
>
> ### Set up the Printer
> 
> 1. Ensure that the printer is calibrated and the bed level is correctly set using the printer-specific instructions.
> 2. Clean the print bed, making sure it is free from dust or grease. If cleaning the bed using water or another liquid, dry the bed.
> 3. If your printer recommends it, use a standard glue stick and apply a thin, even layer of glue across the print area of the bed. Avoid clumping or uneven application.
> 4. Load the printer filament using printer-specific instructions.
> 5. Ensure the printer settings match the suggested settings (most printers have multiple settings, so choose the closest match).
> 6. Set supports everywhere, but ignore slopes greater than 45 degrees to the horizontal.
> 7. There should be no supports in screw holes with horizontal axes.
>
> ### Check Printer Accuracy
>
> 1. The official `Gauges` folder has gauges for checking print size against a standard 4×2 Lego block or an STS3215 servo.
>    1. If you have an STS3215 servo, print **Gauge Zero** (`Gauge_0.STL`).
>    2. Test Gauge Zero against the servo. The fit should be tight but not stuck.
> 2. If the fit is appropriate, move on. Otherwise, change the printer settings and try again, or create an issue.
>
> ### Print the Parts
>
> Print the individual STL files in this folder.

For the complete and current official instructions, including material, nozzle,
layer height, infill, and the alternative gauges, see the
[official “Printing the Parts” section](https://github.com/TheRobotStudio/SO-ARM100#printing-the-parts).

## Included files

### Follower arm parts (11)

1. `Base_motor_holder_SO101.stl`
2. `Base_SO101.stl`
3. `Motor_holder_SO101_Base.stl`
4. `Motor_holder_SO101_Wrist.stl`
5. `Under_arm_SO101.stl`
6. `Upper_arm_SO101.stl`
7. `Rotation_Pitch_SO101.stl`
8. `Wrist_Roll_Pitch_SO101.stl`
9. `WaveShare_Mounting_Plate_SO101.stl`
10. `Moving_Jaw_SO101.stl`
11. `Wrist_Roll_Follower_SO101.stl`

### Calibration gauge (1)

- `Gauge_0.STL`

The official repository is licensed under [Apache-2.0](https://github.com/TheRobotStudio/SO-ARM100/blob/main/LICENSE).
