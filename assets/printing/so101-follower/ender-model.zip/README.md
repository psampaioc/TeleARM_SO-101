# SO-101 follower print models

This package contains the combined Ender follower STL and the official fit gauge. The model files are byte-identical to the upstream source at commit `7629d2ad9853d10fb903093a33ef6114099d97e5`.

Use the upstream [printing and assembly guide](https://github.com/TheRobotStudio/SO-ARM100/blob/7629d2ad9853d10fb903093a33ef6114099d97e5/3DPRINT.md) for print settings and the [project README](https://github.com/TheRobotStudio/SO-ARM100/tree/7629d2ad9853d10fb903093a33ef6114099d97e5) for assembly. The Ender model is intended for an approximately 220 x 220 mm print bed.
